import React from "react";
import { Link } from "react-router-dom";
import { useAppContext } from "./AppContext";

const Header = () => {
    const { user } = useAppContext();

    return (
        <header className="w-full shadow bg-white sticky top-0">
            <div className="mx-auto flex items-center justify-between px-16 py-3">
                <Link to="/" className="text-2xl font-bold">
                    BookHive
                </Link>
                <div className="flex items-center gap-4">
                    {user ? (
                        <Link
                            to="/profile"
                            className="text-m font-medium text-blue-600 hover:underline"
                        >
                            Профіль
                        </Link>
                    ) : (
                        <>
                            <Link
                                to="/login"
                                className="text-m font-medium text-blue-600 hover:underline"
                            >
                                Увійти
                            </Link>
                            <Link
                                to="/register"
                                className="text-m font-medium text-blue-600 hover:underline"
                            >
                                Зареєструватись
                            </Link>
                        </>
                    )}
                </div>
            </div>
        </header>
    );
};

export default Header;