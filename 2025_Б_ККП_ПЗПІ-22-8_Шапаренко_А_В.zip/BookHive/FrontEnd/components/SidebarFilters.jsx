import React from "react";

const allGenres = ["Детектив", "Трилер", "Історичний роман", "Біографія", "Мотивація",
                          "Класика", "Гумор", "Наукова література", "Пригоди", "Містика",
                          "Драма", "Поезія", "Есеїстика", "Фентезі", "Фантастика"];

const recentYears = [];
for (let year = 2025; year >= 2010; year--) {
    recentYears.push(year.toString());
}

const decades = ["2000-ті", "1990-ті", "1980-ті", "1970-ті", "1960-ті", "1950-ті",
                        "1940-ті", "1930-ті", "1920-ті", "1910-ті", "1900-ті"];

const sortOptions = ["Алфавітом", "Рейтингом", "Датою виходу"];

const SidebarFilters = ({
                            selectedGenres,
                            setSelectedGenres,
                            selectedYears,
                            setSelectedYears,
                            sortBy,
                            setSortBy,
                        }) => {
    const toggleGenre = (genre) => {
        setSelectedGenres((prev) =>
            prev.includes(genre)
                ? prev.filter((g) => g !== genre)
                : [...prev, genre]
        );
    };

    const toggleYearGroup = (group) => {
        setSelectedYears((prev) =>
            prev.includes(group)
                ? prev.filter((g) => g !== group)
                : [...prev, group]
        );
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-bold mb-4">Фільтри</h3>

            <div className="mb-6">
                <h4 className="font-semibold mb-3">Жанри:</h4>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                    {allGenres.map((genre) => (
                        <label key={genre} className="flex items-center">
                            <input
                                type="checkbox"
                                checked={selectedGenres.includes(genre)}
                                onChange={() => toggleGenre(genre)}
                                className="mr-2"
                            />
                            {genre}
                        </label>
                    ))}
                </div>
            </div>

            <div className="mb-6">
                <h4 className="font-semibold mb-3">Роки написання:</h4>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                    <div className="border-b pb-2 mb-2">
                        <h5 className="text-sm font-medium text-gray-600 mb-2">Останні роки:</h5>
                        {recentYears.map((year) => (
                            <label key={year} className="flex items-center mb-1">
                                <input
                                    type="checkbox"
                                    checked={selectedYears.includes(year)}
                                    onChange={() => toggleYearGroup(year)}
                                    className="mr-2"
                                />
                                {year}
                            </label>
                        ))}
                    </div>

                    <div className="border-b pb-2 mb-2">
                        <h5 className="text-sm font-medium text-gray-600 mb-2">Десятиліття:</h5>
                        {decades.map((decade) => (
                            <label key={decade} className="flex items-center mb-1">
                                <input
                                    type="checkbox"
                                    checked={selectedYears.includes(decade)}
                                    onChange={() => toggleYearGroup(decade)}
                                    className="mr-2"
                                />
                                {decade}
                            </label>
                        ))}
                    </div>

                    <div>
                        <label className="flex items-center">
                            <input
                                type="checkbox"
                                checked={selectedYears.includes("Старше")}
                                onChange={() => toggleYearGroup("Старше")}
                                className="mr-2"
                            />
                            Старше 1900 року
                        </label>
                    </div>
                </div>
            </div>

            <div className="mb-4">
                <h4 className="font-semibold mb-3">Сортувати за:</h4>
                <div className="space-y-2">
                    {sortOptions.map((option) => (
                        <label key={option} className="flex items-center">
                            <input
                                type="radio"
                                name="sort"
                                checked={sortBy === option}
                                onChange={() => setSortBy(option)}
                                className="mr-2"
                            />
                            {option}
                        </label>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default SidebarFilters;