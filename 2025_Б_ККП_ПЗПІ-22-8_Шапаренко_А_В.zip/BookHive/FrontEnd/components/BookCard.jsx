import React from 'react';
import { useNavigate } from 'react-router-dom';

const BookCard = ({ book }) => {
    const navigate = useNavigate();

    const handleCardClick = () => {
        navigate(`/books/${book.bookId}`);
    };

    const getYear = (date) => {
        if (!date) return 'Невідомо';

        if (Array.isArray(date)) {
            return date[0];
        }

        if (typeof date === 'string') {
            return new Date(date).getFullYear();
        }

        return date.getFullYear ? date.getFullYear() : 'Невідомо';
    };

    return (
        <div
            className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-shadow duration-200"
            onClick={handleCardClick}
        >
            <img
                src={book.image || "https://img.fruugo.com/product/4/89/191618894_max.jpg"}
                alt={book.title}
                className="w-full h-48 object-cover"
            />

            <div className="p-4">
                <h3 className="font-semibold text-lg mb-2 line-clamp-2">
                    {book.title}
                </h3>

                {book.authors && book.authors.length > 0 && (
                    <p className="text-gray-600 text-sm mb-2">
                        {Array.from(book.authors).join(', ')}
                    </p>
                )}

                {book.genres && book.genres.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-2">
                        {book.genres.slice(0, 2).map((genre, index) => (
                            <span
                                key={index}
                                className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded"
                            >
                                {genre}
                            </span>
                        ))}
                        {book.genres.length > 2 && (
                            <span className="text-gray-500 text-xs">
                                +{book.genres.length - 2}
                            </span>
                        )}
                    </div>
                )}

                <div className="flex justify-between items-center mt-3">
                    <span className="text-gray-500 text-sm">
                        {getYear(book.publishing_year)}
                    </span>

                    {book.rating && (
                        <div className="flex items-center">
                            <span className="text-yellow-500 mr-1">★</span>
                            <span className="text-sm font-medium">
                                {book.rating.toFixed(1)}
                            </span>
                        </div>
                    )}
                </div>

                {book.pages && (
                    <p className="text-gray-500 text-xs mt-2">
                        {book.pages} стор.
                    </p>
                )}
            </div>
        </div>
    );
};

export default BookCard;