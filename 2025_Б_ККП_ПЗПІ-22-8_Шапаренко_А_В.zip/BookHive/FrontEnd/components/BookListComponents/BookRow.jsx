import React, { useState } from "react";
import EditableCell from "./EditableCell";
import { updatePagesRead, updateRating } from "../network/api";
import { useAppContext } from "../AppContext";

const BookRow = ({ book, entry, index, listName, onNavigate, onUpdate }) => {
    const [isHoveringRating, setIsHoveringRating] = useState(false);
    const [isHoveringPages, setIsHoveringPages] = useState(false);
    const { user } = useAppContext();

    if (!book) return null;

    const handleRatingUpdate = async (newRating) => {
        let clampedRating = Math.max(1, Math.min(5, newRating));

        try {
            await updateRating(user.userId, book.bookId, clampedRating);
            onUpdate(listName, index, "book_rating", clampedRating);
        } catch (error) {
            console.error("Помилка оновлення рейтингу:", error);
        }
    };

    const handlePagesUpdate = async (newPages) => {
        const totalPages = book.pages || book.totalPages || 0;
        const pages = Math.floor(newPages);

        let clampedPages = Math.max(0, Math.min(totalPages, pages));

        try {
            await updatePagesRead(user.userId, book.bookId, clampedPages);
            onUpdate(listName, index, "pages_read", clampedPages);
        } catch (error) {
            console.error("Помилка поновлення сторінок:", error);
        }
    };

    const totalPages = book.pages || book.totalPages || 0;

    return (
        <tr>
            <td className="text-center">{index + 1}</td>
            <td
                className="book-title-cell cursor-pointer"
                onClick={() => onNavigate(`/books/${book.bookId}`)}
            >
                {book.title || book.name || 'Без назви'}
            </td>
            <td
                className="py-2 text-center"
                onMouseEnter={() => setIsHoveringRating(true)}
                onMouseLeave={() => setIsHoveringRating(false)}
            >
                <EditableCell
                    value={entry.userRating >= 1 ? entry.userRating.toString() : "-"}
                    onSave={handleRatingUpdate}
                    type="number"
                    min={1}
                    max={5}
                    step={1}
                    isHovering={isHoveringRating}
                    hoverValue={entry.userRating >= 1 ? entry.userRating : undefined}
                />
            </td>
            <td
                className="py-2 text-center"
                onMouseEnter={() => setIsHoveringPages(true)}
                onMouseLeave={() => setIsHoveringPages(false)}
            >
                <EditableCell
                    value={`${entry.pagesRead || 0}/${totalPages}`}
                    onSave={handlePagesUpdate}
                    type="number"
                    min={0}
                    max={totalPages}
                    step={1}
                    isHovering={isHoveringPages}
                    hoverValue={entry.pagesRead ?? 0}
                />
            </td>
        </tr>
    );
};

export default BookRow;