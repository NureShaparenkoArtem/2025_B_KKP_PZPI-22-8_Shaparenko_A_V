import React, { useState } from "react";

const EditableCell = ({ value, onSave, type = "text", min, max, step, isHovering, hoverValue }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editValue, setEditValue] = useState("");

    const startEdit = () => {
        setIsEditing(true);
        setEditValue(value.toString());
    };

    const saveEdit = () => {
        const newValue = type === "number" ? parseFloat(editValue) : editValue;
        if (type === "number" && (isNaN(newValue) || newValue < min || newValue > max)) {
            setEditValue(value.toString());
        } else {
            onSave(newValue);
        }
        setIsEditing(false);
    };

    const handleKeyDown = (e) => {
        if (e.key === "Enter") saveEdit();
        if (e.key === "Escape") setIsEditing(false);
    };

    if (isEditing) {
        return (
            <input
                type={type}
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                onBlur={saveEdit}
                onKeyDown={handleKeyDown}
                min={min}
                max={max}
                step={step}
                className="w-16 px-2 py-1 border rounded"
                autoFocus
            />
        );
    }

    const displayValue = isHovering && hoverValue !== undefined ? hoverValue : value;

    return (
        <span
            className="cursor-pointer text-black"
            onClick={startEdit}
        >
            {displayValue}
        </span>
    );
};

export default EditableCell;