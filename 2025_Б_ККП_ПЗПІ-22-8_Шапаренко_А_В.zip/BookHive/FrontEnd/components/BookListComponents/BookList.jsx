import React from "react";
import BookRow from "./BookRow";

const BookList = ({ bookEntries, books, title, listName, onNavigate, onUpdate }) => {
    if (bookEntries.length === 0) {
        return (
            <div className="mb-8">
                <h2 className="text-2xl font-bold mb-4">{title}</h2>
                <p className="text-gray-500">Список порожній</p>
            </div>
        );
    }

    return (
        <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">{title}</h2>
            <div className="overflow-x-auto">
                <table className="w-full bg-white shadow rounded">
                    <thead>
                    <tr className="bg-gray-100 border-b border-gray-300">
                        <th className="py-2 text-left text-black w-[5%] text-center">#</th>
                        <th className="py-2 text-left text-black w-[75%]">Назва</th>
                        <th className="py-2 text-left text-black w-[10%] text-center">Оцінка</th>
                        <th className="py-2 text-left text-black w-[10%] text-center">Прочитано</th>
                    </tr>
                    </thead>
                    <tbody>
                    {bookEntries.map((entry, index) => {

                        return (
                            <BookRow
                                key={`${listName}-${entry.book?.bookId || index}`}
                                book={entry.book}
                                entry={{
                                    id: entry.book?.bookId,
                                    userRating: entry.book_rating,
                                    pagesRead: entry.pages_read,
                                    status: entry.status
                                }}
                                index={index}
                                listName={listName}
                                onNavigate={onNavigate}
                                onUpdate={onUpdate}
                            />
                        );
                    })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default BookList;