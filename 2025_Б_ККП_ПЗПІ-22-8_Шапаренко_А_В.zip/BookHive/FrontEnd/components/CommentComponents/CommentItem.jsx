import React, { useState } from "react";
import { ChevronUp, ChevronDown, Star } from "lucide-react";

const CommentItem = ({ comment, onVote }) => {
    const [userVote, setUserVote] = useState(null);

    const handleVote = (voteType) => {
        const newVote = userVote === voteType ? null : voteType;
        setUserVote(newVote);

        let scoreChange = 0;
        if (userVote === 'up' && newVote === 'down') scoreChange = -2;
        else if (userVote === 'down' && newVote === 'up') scoreChange = 2;
        else if (userVote === null && newVote === 'up') scoreChange = 1;
        else if (userVote === null && newVote === 'down') scoreChange = -1;
        else if (userVote === 'up' && newVote === null) scoreChange = -1;
        else if (userVote === 'down' && newVote === null) scoreChange = 1;

        onVote(comment.comment_id, scoreChange);
    };

    const formatDate = (date) => {
        if (!date) return 'Дата невідома';

        const dateObj = new Date(date);
        if (isNaN(dateObj)) return 'Дата невідома';

        return dateObj.toLocaleDateString('uk-UA', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    };

    const renderStars = (rating) => {
        if (!rating) return null;

        return (
            <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                        key={star}
                        size={14}
                        className={`${
                            star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                        }`}
                    />
                ))}
                <span className="text-sm text-gray-600">({rating}/5)</span>
            </div>
        );
    };

    return (
        <div className="border-b border-gray-200 py-4">
            <div className="flex gap-3">
                <div className="flex flex-col items-center gap-1">
                    <button
                        onClick={() => handleVote('up')}
                        className={`p-1 rounded hover:bg-gray-100 transition ${
                            userVote === 'up' ? 'text-green-500' : 'text-gray-400'
                        }`}
                    >
                        <ChevronUp size={20} />
                    </button>

                    <span className="text-sm font-medium">
                        {comment.comment_likes || 0}
                    </span>

                    <button
                        onClick={() => handleVote('down')}
                        className={`p-1 rounded hover:bg-gray-100 transition ${
                            userVote === 'down' ? 'text-red-500' : 'text-gray-400'
                        }`}
                    >
                        <ChevronDown size={20} />
                    </button>
                </div>

                <div className="flex-1">
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                        <span className="font-medium text-gray-900">
                            {comment.user_name} {comment.user_lastname}
                        </span>
                        •
                        {formatDate(comment.comment_date)}
                        {comment.book_rating && comment.book_rating > 0 && (
                            <>
                                •
                                <div className="flex items-center">
                                    {renderStars(comment.book_rating)}
                                </div>
                            </>
                        )}
                    </div>
                    <p className="text-gray-800 leading-relaxed">{comment.comment_body}</p>
                </div>
            </div>
        </div>
    );
};

export default CommentItem;