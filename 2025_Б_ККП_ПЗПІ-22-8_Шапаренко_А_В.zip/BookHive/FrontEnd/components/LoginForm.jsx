import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { loginUser } from "./network/api";
import { useAppContext } from "./AppContext";

const LoginForm = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();
    const { setUser } = useAppContext();

    const handleLogin = async () => {
        try {
            const user = await loginUser(email, password);
            setUser(user);
            navigate("/profile");
        } catch (err) {
            setError("Невірний email або пароль");
        }
    };

    return (
        <div className="max-w-sm mx-auto bg-white p-6 rounded shadow">
            <div className="relative mb-6">
                <Link
                    to="/"
                    className="absolute left-0 top-1/2 -translate-y-1/2 text-sm text-blue-600 hover:underline"
                >
                    ← На головну
                </Link>
                <h2 className="text-2xl font-bold text-center">Вхід</h2>
            </div>

            <div className="space-y-4">
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full border border-gray-300 rounded px-3 py-2"
                />
                <input
                    type="password"
                    placeholder="Пароль"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full border border-gray-300 rounded px-3 py-2"
                />
                {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                <button
                    onClick={handleLogin}
                    className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
                >
                    Увійти
                </button>
                <p className="text-sm text-center">
                    Немає акаунту?{" "}
                    <Link to="/register" className="text-blue-600 hover:underline">
                        Зареєструйтесь
                    </Link>
                </p>
            </div>
        </div>
    );
};

export default LoginForm;