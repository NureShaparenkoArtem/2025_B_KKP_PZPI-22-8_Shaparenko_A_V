const API_URL = "http://localhost:8080/api/v01";

export const loginUser = async (email, password) => {
    const response = await fetch(`${API_URL}/users/login?email=${email}&password=${password}`);
    if (!response.ok) throw new Error("Невірний email або пароль");
    return await response.json();
};

export const registerUser = async (userData) => {
    const response = await fetch(`${API_URL}/users/register`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
    });
    if (!response.ok) throw new Error("Помилка реєстрації");
    return await response.json();
};

export const getAllBooks = async () => {
    try {
        const response = await fetch(`${API_URL}/books/getAll`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error("Помилка завантаження книг:", error);
        throw new Error("Не вдалося завантажити книги");
    }
};

export const getRecommendedBooks = async (userId) => {
    try {
        const response = await fetch(`${API_URL}/listsofbooks/recommendation/${userId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error("Помилка завантаження рекомендованих книг:", error);
        throw new Error("Не вдалося завантажити рекомендовані книги");
    }
};

export const getTopBooks = async (limit = 6) => {
    try {
        const allBooks = await getAllBooks();
        return allBooks
            .sort((a, b) => (b.rating || 0) - (a.rating || 0))
            .slice(0, limit);
    } catch (error) {
        console.error("Помилка завантаження топ книг:", error);
        throw new Error("Не вдалося завантажити топ книги");
    }
};

export const getBookById = async (bookId) => {
    try {
        const response = await fetch(`${API_URL}/books/getBook/${bookId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Помилка завантаження книги з ID ${bookId}:`, error);
        throw new Error("Не вдалося завантажити книгу");
    }
};

export const getPlannedBooks = async (userId) => {
    try {
        const response = await fetch(`${API_URL}/listsofbooks/getBooks/planned/${userId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error("Помилка завантаження запланованих книг:", error);
        throw new Error("Не вдалося завантажити заплановані книги");
    }
};

export const getReadingBooks = async (userId) => {
    try {
        const response = await fetch(`${API_URL}/listsofbooks/getBooks/reading/${userId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error("Помилка завантаження книг що читаються:", error);
        throw new Error("Не вдалося завантажити книги що читаються");
    }
};

export const getAbandonedBooks = async (userId) => {
    try {
        const response = await fetch(`${API_URL}/listsofbooks/getBooks/abandoned/${userId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error("Помилка завантаження покинутих книг:", error);
        throw new Error("Не вдалося завантажити покинуті книги");
    }
};

export const getBookComments = async (bookId) => {
    try {
        const response = await fetch(`${API_URL}/comments/${bookId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Помилка завантаження коментарів для книги з ID ${bookId}:`, error);
        throw new Error("Не вдалося завантажити коментарі");
    }
};

export const addBookToList = async (bookId, user, status) => {
    try {
        const response = await fetch(`${API_URL}/listsofbooks/addBook/${bookId}?userId=${encodeURIComponent(user.userId)}&status=${encodeURIComponent(status)}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error("Помилка додавання книги до списку:", error);
        throw new Error("Не вдалося додати книгу до списку");
    }
};

export const updateRating = async (userId, bookId, rating) => {
    try {
        const response = await fetch(`${API_URL}/listsofbooks/updateRating?userId=${userId}&bookId=${bookId}&rating=${rating}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error("Помилка оновлення рейтингу:", error);
        throw new Error("Не вдалося оновити рейтинг");
    }
};

export const updatePagesRead = async (userId, bookId, pagesRead) => {
    try {
        const response = await fetch(`${API_URL}/listsofbooks/updatePagesRead?userId=${userId}&bookId=${bookId}&pagesRead=${pagesRead}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error("Помилка оновлення сторінок:", error);
        throw new Error("Не вдалося оновити кількість прочитаних сторінок");
    }
};