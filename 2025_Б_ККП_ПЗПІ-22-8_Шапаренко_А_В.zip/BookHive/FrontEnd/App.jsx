import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import Homepage from "./pages/Homepage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import AllBooksPage from "./pages/AllBooksPage";
import BookDetailsPage from "./pages/BookDetailsPage";
import ProfilePage from "./pages/ProfilePage";
import Header from "./components/Header";

const Layout = ({ children, isAuthenticated }) => {
    const location = useLocation();
    const authPages = ["/login", "/register"];
    const hideHeader = authPages.includes(location.pathname);

    return (
        <div className="min-h-screen bg-gray-100">
            {!hideHeader && <Header isAuthenticated={isAuthenticated}/>}
            <main className="px-[20%] pt-8">
                {children}
            </main>
        </div>
    );
};

const App = () => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    return (
        <Router>
            <Layout isAuthenticated={isAuthenticated}>
                <Routes>
                    <Route path="/" element={<Homepage />} />
                    <Route path="/login" element={<LoginPage setIsAuthenticated={setIsAuthenticated}/>} />
                    <Route path="/register" element={<RegisterPage />} />
                    <Route path="/books" element={<AllBooksPage />} />
                    <Route path="/books/:id" element={<BookDetailsPage />} />
                    <Route path="/profile" element={<ProfilePage isAuthenticated={isAuthenticated}/>} />
                </Routes>
            </Layout>
        </Router>
    );
};

export default App;
