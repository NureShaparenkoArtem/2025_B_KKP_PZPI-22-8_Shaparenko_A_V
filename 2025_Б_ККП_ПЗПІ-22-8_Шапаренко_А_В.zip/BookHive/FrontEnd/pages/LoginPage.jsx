import React from "react";
import LoginForm from "../components/LoginForm";

const LoginPage = ({ setIsAuthenticated }) => {
    return (
        <div className="min-h-screen flex items-center justify-center">
            <LoginForm setIsAuthenticated={setIsAuthenticated} />
        </div>
    );
};

export default LoginPage;