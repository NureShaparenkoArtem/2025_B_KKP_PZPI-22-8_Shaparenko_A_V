import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import BookCard from "../components/BookCard";
import { getRecommendedBooks, getTopBooks } from "../components/network/api";
import { useAppContext } from "../components/AppContext";

const Homepage = () => {
    const [books, setBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isRecommended, setIsRecommended] = useState(false);

    const { user } = useAppContext();

    useEffect(() => {
        const loadBooks = async () => {
            try {
                setLoading(true);
                setError(null);

                const userId = user?.userId;

                let booksData = [];

                if (userId) {
                    try {
                        booksData = await getRecommendedBooks(userId);
                        if (booksData && booksData.length > 0) {
                            setIsRecommended(true);
                            setBooks(booksData.slice(0, 6));
                        } else {
                            throw new Error("Нет рекомендаций");
                        }
                    } catch (recommendationError) {
                        console.log("Рекомендации недоступны, загружаем топ книги");
                        booksData = await getTopBooks(6);
                        setIsRecommended(false);
                        setBooks(booksData);
                    }
                } else {
                    booksData = await getTopBooks(6);
                    setIsRecommended(false);
                    setBooks(booksData);
                }
            } catch (err) {
                setError("Не вдалося завантажити книги");
                console.error("Помилка завантаження книг:", err);
            } finally {
                setLoading(false);
            }
        };

        loadBooks();
    }, [user]);

    if (loading) {
        return (
            <section className="flex justify-center items-center min-h-[400px]">
                <div className="text-gray-500">Завантаження...</div>
            </section>
        );
    }

    if (error) {
        return (
            <section className="flex justify-center items-center min-h-[400px]">
                <div className="text-red-500">{error}</div>
            </section>
        );
    }

    return (
        <section>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">
                    {isRecommended
                        ? "Рекомендовані для вас"
                        : "Популярні книги"
                    }
                </h2>
                <Link to="/books" className="text-gray-500 hover:underline text-sm font-medium">
                    Усі книжки →
                </Link>
            </div>

            {books.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                    {isRecommended
                        ? "Поки що немає рекомендацій. Додайте книги до списку 'Читаю' для отримання персональних рекомендацій."
                        : "Книги не знайдено"
                    }
                </div>
            ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-5">
                    {books.map((book) => (
                        <BookCard key={book.bookId} book={book} />
                    ))}
                </div>
            )}
        </section>
    );
};

export default Homepage;