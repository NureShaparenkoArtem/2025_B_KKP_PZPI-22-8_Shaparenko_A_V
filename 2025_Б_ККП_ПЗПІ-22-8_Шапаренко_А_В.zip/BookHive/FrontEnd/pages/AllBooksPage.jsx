import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import BookCard from "../components/BookCard";
import SidebarFilters from "../components/SidebarFilters";
import { getAllBooks } from "../components/network/api";

const getYearFromDate = (book) => {
    const publishDate = book.publishDate || book.publishing_year || book.publishingYear || book.year;

    if (!publishDate) {
        return null;
    }

    if (typeof publishDate === 'number') {
        return publishDate;
    }

    if (typeof publishDate === 'string' && publishDate.includes('.')) {
        return parseInt(publishDate.split('.')[0]);
    }

    return new Date(publishDate).getFullYear();
};

const getYearGroup = (book) => {
    const year = getYearFromDate(book);

    if (!year || isNaN(year)) return "Невідомо";

    if (year >= 2010 && year <= 2025) {
        return year.toString();
    }

    if (year >= 2000 && year < 2010) return "2000-ті";
    if (year >= 1990 && year < 2000) return "1990-ті";
    if (year >= 1980 && year < 1990) return "1980-ті";
    if (year >= 1970 && year < 1980) return "1970-ті";
    if (year >= 1960 && year < 1970) return "1960-ті";
    if (year >= 1950 && year < 1960) return "1950-ті";
    if (year >= 1940 && year < 1950) return "1940-ті";
    if (year >= 1930 && year < 1940) return "1930-ті";
    if (year >= 1920 && year < 1930) return "1920-ті";
    if (year >= 1910 && year < 1920) return "1910-ті";
    if (year >= 1900 && year < 1910) return "1900-ті";

    return "Старше";
};

const AllBooksPage = () => {
    const [searchParams, setSearchParams] = useSearchParams();

    const [books, setBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedGenres, setSelectedGenres] = useState([]);
    const [selectedYears, setSelectedYears] = useState([]);
    const [sortBy, setSortBy] = useState("Рейтингом");

    useEffect(() => {
        const loadBooks = async () => {
            try {
                setLoading(true);
                setError(null);
                const booksData = await getAllBooks();
                console.log("Loaded books:", booksData);
                console.log("First book structure:", booksData[0]);
                setBooks(booksData);
            } catch (err) {
                setError(err.message);
                console.error("Failed to load books:", err);
            } finally {
                setLoading(false);
            }
        };

        loadBooks();
    }, []);

    useEffect(() => {
        const genres = searchParams.get("genres");
        const years = searchParams.get("years");
        const sort = searchParams.get("sort");

        if (genres) setSelectedGenres(genres.split(","));
        if (years) setSelectedYears(years.split(","));
        if (sort) setSortBy(sort);
    }, [searchParams]);

    useEffect(() => {
        const params = {};

        if (selectedGenres.length) params.genres = selectedGenres.join(",");
        if (selectedYears.length) params.years = selectedYears.join(",");
        if (sortBy !== "Рейтингом") params.sort = sortBy;

        setSearchParams(params);
    }, [selectedGenres, selectedYears, sortBy, setSearchParams]);

    const filteredBooks = books
        .filter((book) => {
            const genreMatch =
                selectedGenres.length === 0 ||
                (book.genres && book.genres.some((g) => selectedGenres.includes(g)));

            const yearGroup = getYearGroup(book);
            const yearMatch =
                selectedYears.length === 0 || selectedYears.includes(yearGroup);

            return genreMatch && yearMatch;
        })
        .sort((a, b) => {
            switch (sortBy) {
                case "Алфавітом":
                    return (a.title || "").localeCompare(b.title || "");
                case "Рейтингом":
                    return (b.rating || 0) - (a.rating || 0);
                case "Датою виходу":
                    const yearA = getYearFromDate(a) || 0;
                    const yearB = getYearFromDate(b) || 0;
                    return yearB - yearA;
                default:
                    return 0;
            }
        });

    const availableGenres = [...new Set(books.flatMap(book => book.genres || []))];
    const availableYears = [...new Set(books.map(book => getYearGroup(book)).filter(Boolean))];

    return (
        <div>
            <h1 className="text-2xl font-bold mb-6">Усі книжки</h1>

            {loading && (
                <div className="flex justify-center items-center py-8">
                    <div className="text-lg text-gray-600">Завантаження книг...</div>
                </div>
            )}

            {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    <strong>Помилка:</strong> {error}
                </div>
            )}

            {!loading && !error && (
                <div className="flex gap-6">
                    <div className="flex-1">
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {filteredBooks.map((book) => (
                                <BookCard key={book.id} book={book} />
                            ))}
                            {filteredBooks.length === 0 && books.length > 0 && (
                                <p className="col-span-full text-gray-500">
                                    Книг за вашими фільтрами не знайдено.
                                </p>
                            )}
                            {books.length === 0 && (
                                <p className="col-span-full text-gray-500">
                                    Книг не знайдено в базі даних.
                                </p>
                            )}
                        </div>
                    </div>
                    <div className="w-64 shrink-0">
                        <SidebarFilters
                            selectedGenres={selectedGenres}
                            setSelectedGenres={setSelectedGenres}
                            selectedYears={selectedYears}
                            setSelectedYears={setSelectedYears}
                            sortBy={sortBy}
                            setSortBy={setSortBy}
                            availableGenres={availableGenres}
                            availableYears={availableYears}
                        />
                    </div>
                </div>
            )}
        </div>
    );
};

export default AllBooksPage;