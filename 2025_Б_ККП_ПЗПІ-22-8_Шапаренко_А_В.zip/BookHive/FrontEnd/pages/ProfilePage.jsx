import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import BookList from "../components/BookListComponents/BookList";
import { useAppContext } from "../components/AppContext";
import { getAllBooks, getPlannedBooks, getReadingBooks, getAbandonedBooks } from "../components/network/api";

const ProfilePage = () => {
    const { user } = useAppContext();
    const [books, setBooks] = useState([]);
    const [userBooks, setUserBooks] = useState({ planned: [], reading: [], abandoned: [] });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        if (!user) {
            navigate("/login");
            return;
        }

        const fetchData = async () => {
            setLoading(true);
            setError(null);

            try {
                const [booksData, plannedData, readingData, abandonedData] = await Promise.all([
                    getAllBooks(),
                    getPlannedBooks(user.userId),
                    getReadingBooks(user.userId),
                    getAbandonedBooks(user.userId)
                ]);

                setBooks(booksData);
                setUserBooks({
                    planned: plannedData,
                    reading: readingData,
                    abandoned: abandonedData
                });
            } catch (error) {
                console.error("Error fetching data:", error);
                setError("Помилка завантаження даних");
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [user, navigate]);

    const handleBookUpdate = (listName, index, field, value) => {
        setUserBooks(prev => ({
            ...prev,
            [listName]: prev[listName].map((book, i) =>
                i === index ? { ...book, [field]: value } : book
            )
        }));
    };

    if (!user) {
        return <p className="text-center mt-10 text-gray-500">Завантаження...</p>;
    }

    if (loading) {
        return <p className="text-center mt-10 text-gray-500">Завантаження даних...</p>;
    }

    if (error) {
        return <p className="text-center mt-10 text-red-500">{error}</p>;
    }

    const bookLists = [
        { key: "planned", title: "Заплановані" },
        { key: "reading", title: "Читаю" },
        { key: "abandoned", title: "Покинуті" }
    ];

    return (
        <div className="max-w-screen-xl mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold mb-6">Профіль користувача</h1>
            <p className="mb-4"><strong>Ім'я:</strong> {user.user_name} {user.user_lastname}</p>
            <p className="mb-8"><strong>Email:</strong> {user.email}</p>

            {bookLists.map(({ key, title }) => (
                <BookList
                    key={key}
                    bookEntries={userBooks[key]}
                    books={books}
                    title={title}
                    listName={key}
                    onNavigate={navigate}
                    onUpdate={handleBookUpdate}
                />
            ))}
        </div>
    );
};

export default ProfilePage;