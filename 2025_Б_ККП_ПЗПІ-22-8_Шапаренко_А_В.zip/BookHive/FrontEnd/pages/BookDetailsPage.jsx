import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getBookById, getBookComments, createComment, addBookToList } from "../components/network/api";
import CommentItem from "../components/CommentComponents/CommentItem";
import { useAppContext } from "../components/AppContext";

const BookDetailsPage = () => {
    const { id } = useParams();
    const { user } = useAppContext();
    const [book, setBook] = useState(null);
    const [status, setStatus] = useState("Заплановані");
    const [comments, setComments] = useState([]);
    const [newComment, setNewComment] = useState("");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [commentsLoading, setCommentsLoading] = useState(false);
    const [isSubmittingComment, setIsSubmittingComment] = useState(false);
    const [isAddingToList, setIsAddingToList] = useState(false);

    const formatDate = (date) => {
        if (!date) return 'Дата невідома';

        if (Array.isArray(date)) {
            const [year, month, day] = date;
            const months = [
                "січня", "лютого", "березня", "квітня", "травня", "червня",
                "липня", "серпня", "вересня", "жовтня", "листопада", "грудня"
            ];
            return `${day} ${months[month - 1]} ${year} року`;
        }

        const dateObj = new Date(date);
        if (isNaN(dateObj)) return 'Дата невідома';

        const months = [
            "січня", "лютого", "березня", "квітня", "травня", "червня",
            "липня", "серпня", "вересня", "жовтня", "листопада", "грудня"
        ];

        const day = dateObj.getDate();
        const month = months[dateObj.getMonth()];
        const year = dateObj.getFullYear();

        return `${day} ${month} ${year} року`;
    };

    const loadComments = async (bookId) => {
        try {
            setCommentsLoading(true);
            const commentsData = await getBookComments(bookId);
            setComments(commentsData);
        } catch (err) {
            console.error("Помилка при завантаженні коментарів:", err);
            setComments([]);
        } finally {
            setCommentsLoading(false);
        }
    };

    useEffect(() => {
        const loadBook = async () => {
            try {
                setLoading(true);
                setError(null);

                const bookData = await getBookById(id);
                setBook(bookData);

                await loadComments(id);

            } catch (err) {
                setError(err.message);
                console.error("Помилка при завантаженні книги:", err);
            } finally {
                setLoading(false);
            }
        };

        if (id) {
            loadBook();
        }
    }, [id]);

    const handleVote = (commentId, scoreChange) => {
        setComments(prev => prev.map(comment =>
            comment.comment_id === commentId
                ? { ...comment, comment_likes: (comment.comment_likes || 0) + scoreChange }
                : comment
        ));
    };

    const handleAddToList = async () => {
        if (!user || !book) return;

        try {
            setIsAddingToList(true);

            await addBookToList(book.bookId, user, status);

            alert(`Книга "${book.title}" успішно додана в список "${status}"`);

        } catch (error) {
            console.error("Помилка при додаванні книги до списку:", error);
            alert("Не вдалося додати книгу до списку. Спробуйте ще раз.");
        } finally {
            setIsAddingToList(false);
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center py-8">
                <div className="text-lg text-gray-600">Завантаження книги...</div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="max-w-screen-xl mx-auto px-4 py-8">
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                    <strong>Помилка:</strong> {error}
                </div>
            </div>
        );
    }

    if (!book) {
        return (
            <div className="max-w-screen-xl mx-auto px-4 py-8">
                <p className="text-center text-red-500 text-lg">Книгу не знайдено</p>
            </div>
        );
    }

    return (
        <div className="max-w-screen-xl mx-auto px-4 py-1">
            <div className="mb-8">
                <h1 className="text-4xl font-bold text-center mb-4">{book.title}</h1>
                {book.genres && book.genres.length > 0 && (
                    <div className="flex justify-center gap-2 mt-2 text-base text-gray-600">
                        {book.genres.map((genre, index) => (
                            <span key={index} className="bg-gray-100 px-3 py-2 rounded-lg text-sm">
                                {genre}
                            </span>
                        ))}
                    </div>
                )}
            </div>

            <div className="flex flex-col md:flex-row gap-12 mb-12">
                <div className="w-full md:w-1/3 flex flex-col items-center">
                    <img
                        src={book.image || "https://img.fruugo.com/product/4/89/191618894_max.jpg"}
                        alt={book.title}
                        className="w-full max-w-xs object-cover rounded-lg shadow-lg"
                    />

                    <div className="mt-6 flex gap-3 w-full max-w-xs">
                        {user ? (
                            <>
                                <select
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                    className="flex-grow px-4 py-3 border rounded-lg bg-white text-base"
                                    disabled={isAddingToList}
                                >
                                    <option value="Заплановані">Заплановані</option>
                                    <option value="Читаю">Читаю</option>
                                    <option value="Покинуті">Покинуті</option>
                                </select>
                                <button
                                    onClick={handleAddToList}
                                    disabled={isAddingToList}
                                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition text-base font-medium disabled:bg-gray-400 disabled:cursor-not-allowed"
                                >
                                    {isAddingToList ? 'Додавання...' : 'Додати'}
                                </button>
                            </>
                        ) : null}
                    </div>
                </div>

                <div className="flex-1">
                    <div className="space-y-3 mb-6 text-lg">
                        {book.authors && book.authors.length > 0 && (
                            <p className="text-gray-700">
                                <strong>Автори:</strong> {Array.from(book.authors).join(", ")}
                            </p>
                        )}

                        <p className="text-gray-700">
                            <strong>Дата виходу:</strong> {formatDate(book.publishing_year)}
                        </p>

                        {book.pages && (
                            <p className="text-gray-700">
                                <strong>Кількість сторінок:</strong> {book.pages}
                            </p>
                        )}

                        {book.rating && (
                            <p className="text-gray-700">
                                <strong>Рейтинг:</strong> {book.rating.toFixed(1)} / 5
                            </p>
                        )}
                    </div>

                    {book.description && (
                        <p className="text-gray-800 text-lg leading-relaxed">{book.description}</p>
                    )}
                </div>
            </div>

            <div className="border-t border-gray-200 pt-8">
                <h2 className="text-2xl font-bold mb-6">Відгуки та коментарі</h2>

                <div className="bg-white rounded-lg border border-gray-200 mb-5">
                    {commentsLoading ? (
                        <div className="p-8 text-center text-gray-500">
                            <p className="text-lg">Завантаження коментарів...</p>
                        </div>
                    ) : comments.length > 0 ? (
                        <div className="p-6">
                            {comments.map(comment => (
                                <CommentItem
                                    key={comment.comment_id}
                                    comment={comment}
                                    onVote={handleVote}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="p-8 text-center text-gray-500">
                            <p className="text-lg">Поки що немає коментарів</p>
                            <p className="text-base mt-2">Будьте першим, хто поділиться думками про цю книгу!</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default BookDetailsPage;